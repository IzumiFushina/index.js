# index.js
Tutorial: 20/09/2023
Autor: Gustavo Gabriel Cunha Manhães

Primeiramente deve-se abrir o terminal utilizando Ctrl + Alt + T;
Após isso acesse o node-env com o comando "source ./nodejs-env/bin/activate";
Entre na pasta pelo terminal, digitando "cd ~/nodejs-env";
Utilize o seguinte comando "node index.js" e assim abra o arquivo;
Para finalizar, abra seu navegador e na barra de digitar endereço escreva "localhost:8031" assim abrindo a desejada página.
